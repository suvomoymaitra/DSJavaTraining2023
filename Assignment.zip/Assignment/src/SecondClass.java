
public class SecondClass {
	public static void main(String[] args) {
		FirstClass fc = new FirstClass(34,56);
		System.out.println("The values are : " + fc.getVarF() + " " + fc.getVarS());
	}
}
