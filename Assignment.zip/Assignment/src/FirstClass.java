public class FirstClass {
	public int varF,varS;
	
	public FirstClass(int varF,int varS){
		this.varF = varF;
		this.varS = varS;
	}
	
	int getVarF() {
		return varF;
	}
	
	int getVarS() {
		return varS;
	}
}
